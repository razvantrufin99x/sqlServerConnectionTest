﻿namespace librarieProject.carti
{
    partial class navigareCarti
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.lblFieldName1 = new System.Windows.Forms.Label();
            this.lblFieldName2 = new System.Windows.Forms.Label();
            this.lblFieldName3 = new System.Windows.Forms.Label();
            this.lblFieldName4 = new System.Windows.Forms.Label();
            this.lblFieldName5 = new System.Windows.Forms.Label();
            this.lblFieldName0 = new System.Windows.Forms.Label();
            this.txtField0 = new System.Windows.Forms.TextBox();
            this.txtField1 = new System.Windows.Forms.TextBox();
            this.txtField2 = new System.Windows.Forms.TextBox();
            this.txtField3 = new System.Windows.Forms.TextBox();
            this.txtField4 = new System.Windows.Forms.TextBox();
            this.txtField5 = new System.Windows.Forms.TextBox();
            this.txtNumberOfTotalRecords = new System.Windows.Forms.TextBox();
            this.txtCurrentRecordNumber = new System.Windows.Forms.TextBox();
            this.lblDBName = new System.Windows.Forms.Label();
            this.lblTabelName = new System.Windows.Forms.Label();
            this.txtListAllRecords = new System.Windows.Forms.TextBox();
            this.txtField6 = new System.Windows.Forms.TextBox();
            this.lblFieldName6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(177, 387);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "|<";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(259, 387);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "<";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(422, 387);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = ">";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(504, 387);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = ">|";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(696, 387);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 4;
            this.button5.Text = "printALL";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // lblFieldName1
            // 
            this.lblFieldName1.AutoSize = true;
            this.lblFieldName1.Location = new System.Drawing.Point(143, 111);
            this.lblFieldName1.Name = "lblFieldName1";
            this.lblFieldName1.Size = new System.Drawing.Size(35, 13);
            this.lblFieldName1.TabIndex = 5;
            this.lblFieldName1.Text = "label1";
            // 
            // lblFieldName2
            // 
            this.lblFieldName2.AutoSize = true;
            this.lblFieldName2.Location = new System.Drawing.Point(143, 151);
            this.lblFieldName2.Name = "lblFieldName2";
            this.lblFieldName2.Size = new System.Drawing.Size(35, 13);
            this.lblFieldName2.TabIndex = 6;
            this.lblFieldName2.Text = "label1";
            // 
            // lblFieldName3
            // 
            this.lblFieldName3.AutoSize = true;
            this.lblFieldName3.Location = new System.Drawing.Point(143, 191);
            this.lblFieldName3.Name = "lblFieldName3";
            this.lblFieldName3.Size = new System.Drawing.Size(35, 13);
            this.lblFieldName3.TabIndex = 7;
            this.lblFieldName3.Text = "label1";
            // 
            // lblFieldName4
            // 
            this.lblFieldName4.AutoSize = true;
            this.lblFieldName4.Location = new System.Drawing.Point(143, 231);
            this.lblFieldName4.Name = "lblFieldName4";
            this.lblFieldName4.Size = new System.Drawing.Size(35, 13);
            this.lblFieldName4.TabIndex = 8;
            this.lblFieldName4.Text = "label1";
            // 
            // lblFieldName5
            // 
            this.lblFieldName5.AutoSize = true;
            this.lblFieldName5.Location = new System.Drawing.Point(143, 271);
            this.lblFieldName5.Name = "lblFieldName5";
            this.lblFieldName5.Size = new System.Drawing.Size(35, 13);
            this.lblFieldName5.TabIndex = 9;
            this.lblFieldName5.Text = "label2";
            // 
            // lblFieldName0
            // 
            this.lblFieldName0.AutoSize = true;
            this.lblFieldName0.Location = new System.Drawing.Point(143, 71);
            this.lblFieldName0.Name = "lblFieldName0";
            this.lblFieldName0.Size = new System.Drawing.Size(35, 13);
            this.lblFieldName0.TabIndex = 11;
            this.lblFieldName0.Text = "label1";
            // 
            // txtField0
            // 
            this.txtField0.Location = new System.Drawing.Point(227, 68);
            this.txtField0.Name = "txtField0";
            this.txtField0.Size = new System.Drawing.Size(270, 20);
            this.txtField0.TabIndex = 12;
            // 
            // txtField1
            // 
            this.txtField1.Location = new System.Drawing.Point(227, 108);
            this.txtField1.Name = "txtField1";
            this.txtField1.Size = new System.Drawing.Size(270, 20);
            this.txtField1.TabIndex = 13;
            // 
            // txtField2
            // 
            this.txtField2.Location = new System.Drawing.Point(227, 148);
            this.txtField2.Name = "txtField2";
            this.txtField2.Size = new System.Drawing.Size(270, 20);
            this.txtField2.TabIndex = 14;
            // 
            // txtField3
            // 
            this.txtField3.Location = new System.Drawing.Point(227, 188);
            this.txtField3.Name = "txtField3";
            this.txtField3.Size = new System.Drawing.Size(270, 20);
            this.txtField3.TabIndex = 15;
            // 
            // txtField4
            // 
            this.txtField4.Location = new System.Drawing.Point(227, 228);
            this.txtField4.Name = "txtField4";
            this.txtField4.Size = new System.Drawing.Size(270, 20);
            this.txtField4.TabIndex = 16;
            // 
            // txtField5
            // 
            this.txtField5.Location = new System.Drawing.Point(227, 268);
            this.txtField5.Name = "txtField5";
            this.txtField5.Size = new System.Drawing.Size(270, 20);
            this.txtField5.TabIndex = 17;
            // 
            // txtNumberOfTotalRecords
            // 
            this.txtNumberOfTotalRecords.Location = new System.Drawing.Point(341, 408);
            this.txtNumberOfTotalRecords.Name = "txtNumberOfTotalRecords";
            this.txtNumberOfTotalRecords.Size = new System.Drawing.Size(75, 20);
            this.txtNumberOfTotalRecords.TabIndex = 18;
            // 
            // txtCurrentRecordNumber
            // 
            this.txtCurrentRecordNumber.Location = new System.Drawing.Point(341, 374);
            this.txtCurrentRecordNumber.Name = "txtCurrentRecordNumber";
            this.txtCurrentRecordNumber.Size = new System.Drawing.Size(75, 20);
            this.txtCurrentRecordNumber.TabIndex = 19;
            // 
            // lblDBName
            // 
            this.lblDBName.AutoSize = true;
            this.lblDBName.Location = new System.Drawing.Point(85, 25);
            this.lblDBName.Name = "lblDBName";
            this.lblDBName.Size = new System.Drawing.Size(35, 13);
            this.lblDBName.TabIndex = 20;
            this.lblDBName.Text = "label1";
            // 
            // lblTabelName
            // 
            this.lblTabelName.AutoSize = true;
            this.lblTabelName.Location = new System.Drawing.Point(216, 24);
            this.lblTabelName.Name = "lblTabelName";
            this.lblTabelName.Size = new System.Drawing.Size(35, 13);
            this.lblTabelName.TabIndex = 21;
            this.lblTabelName.Text = "label1";
            // 
            // txtListAllRecords
            // 
            this.txtListAllRecords.Location = new System.Drawing.Point(600, 16);
            this.txtListAllRecords.Multiline = true;
            this.txtListAllRecords.Name = "txtListAllRecords";
            this.txtListAllRecords.Size = new System.Drawing.Size(190, 349);
            this.txtListAllRecords.TabIndex = 22;
            // 
            // txtField6
            // 
            this.txtField6.Location = new System.Drawing.Point(227, 313);
            this.txtField6.Name = "txtField6";
            this.txtField6.Size = new System.Drawing.Size(270, 20);
            this.txtField6.TabIndex = 24;
            // 
            // lblFieldName6
            // 
            this.lblFieldName6.AutoSize = true;
            this.lblFieldName6.Location = new System.Drawing.Point(143, 316);
            this.lblFieldName6.Name = "lblFieldName6";
            this.lblFieldName6.Size = new System.Drawing.Size(35, 13);
            this.lblFieldName6.TabIndex = 23;
            this.lblFieldName6.Text = "label2";
            // 
            // navigareCarti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 504);
            this.Controls.Add(this.txtField6);
            this.Controls.Add(this.lblFieldName6);
            this.Controls.Add(this.txtListAllRecords);
            this.Controls.Add(this.lblTabelName);
            this.Controls.Add(this.lblDBName);
            this.Controls.Add(this.txtCurrentRecordNumber);
            this.Controls.Add(this.txtNumberOfTotalRecords);
            this.Controls.Add(this.txtField5);
            this.Controls.Add(this.txtField4);
            this.Controls.Add(this.txtField3);
            this.Controls.Add(this.txtField2);
            this.Controls.Add(this.txtField1);
            this.Controls.Add(this.txtField0);
            this.Controls.Add(this.lblFieldName0);
            this.Controls.Add(this.lblFieldName5);
            this.Controls.Add(this.lblFieldName4);
            this.Controls.Add(this.lblFieldName3);
            this.Controls.Add(this.lblFieldName2);
            this.Controls.Add(this.lblFieldName1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "navigareCarti";
            this.Text = "navigareCarti";
            this.Load += new System.EventHandler(this.navigareCarti_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label lblFieldName1;
        private System.Windows.Forms.Label lblFieldName2;
        private System.Windows.Forms.Label lblFieldName3;
        private System.Windows.Forms.Label lblFieldName4;
        private System.Windows.Forms.Label lblFieldName5;
        private System.Windows.Forms.Label lblFieldName0;
        private System.Windows.Forms.TextBox txtField0;
        private System.Windows.Forms.TextBox txtField1;
        private System.Windows.Forms.TextBox txtField2;
        private System.Windows.Forms.TextBox txtField3;
        private System.Windows.Forms.TextBox txtField4;
        private System.Windows.Forms.TextBox txtField5;
        private System.Windows.Forms.TextBox txtNumberOfTotalRecords;
        private System.Windows.Forms.TextBox txtCurrentRecordNumber;
        private System.Windows.Forms.Label lblDBName;
        private System.Windows.Forms.Label lblTabelName;
        private System.Windows.Forms.TextBox txtListAllRecords;
        private System.Windows.Forms.TextBox txtField6;
        private System.Windows.Forms.Label lblFieldName6;
    }
}