﻿namespace librarieProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adaugareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modificareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stergereToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.admintopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.autoriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adaugareToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.modificareToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.stergereToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.selectareToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.cartiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adaugareToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.modificareToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.stergereToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.selectareToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.navigareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.navigareCartiGeneratorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.domeniiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adaugareToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.modificareToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.stergereToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.selectareToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.comentariiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adaugareToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.modificareToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.stergereToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.selectareToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.moderareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.opiniiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vanzariToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adaugareToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.modificareToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.stergereToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.selectareToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.tranzactiiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adaugareToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.modificareToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.stergereToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.selectareToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.clientiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adaugareToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.modificareToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.stergereToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.selectareToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.furnizoriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adaugareToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.modificareToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.stergereToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.selectareToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.statisticiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adminToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cartiToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.autoriToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.comentariiToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.vanzariToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tranzactiiToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.clientiToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.furnizoriToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.platiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.plataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cautareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deconectareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importFromToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.publicareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.facebookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.socialeNetworkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toFlierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toPDFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toWebToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.magazinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.companieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.companyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formulareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lastProductsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.meniuLateralStangaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.topFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frontEndToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backEndToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.curierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.curieratToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dashBoardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fiscalitateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bancaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.caseriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.impozitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.taxeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tVAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contabilitateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bilantToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.costuriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.personalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pierderiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.profitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stocuriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.venituriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reteleSocialeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.emailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.legalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyrightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.securitateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.securityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sesiuneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.autorizareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.autentificareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.signupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.signinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajutorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splashScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateNavigatorAdminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateNavigatorAutoriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 416);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(709, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(709, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.dateToolStripMenuItem,
            this.magazinToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(709, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // dateToolStripMenuItem
            // 
            this.dateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminToolStripMenuItem,
            this.autoriToolStripMenuItem,
            this.cartiToolStripMenuItem,
            this.domeniiToolStripMenuItem,
            this.comentariiToolStripMenuItem,
            this.vanzariToolStripMenuItem,
            this.tranzactiiToolStripMenuItem,
            this.clientiToolStripMenuItem,
            this.furnizoriToolStripMenuItem,
            this.statisticiToolStripMenuItem,
            this.platiToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.dBToolStripMenuItem,
            this.exportToolStripMenuItem,
            this.importToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.publicareToolStripMenuItem});
            this.dateToolStripMenuItem.Name = "dateToolStripMenuItem";
            this.dateToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.dateToolStripMenuItem.Text = "Date";
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adaugareToolStripMenuItem,
            this.modificareToolStripMenuItem,
            this.stergereToolStripMenuItem,
            this.selectareToolStripMenuItem,
            this.adminToolStripMenuItem2,
            this.admintopToolStripMenuItem,
            this.generateNavigatorAdminToolStripMenuItem});
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.adminToolStripMenuItem.Text = "Admin";
            // 
            // adaugareToolStripMenuItem
            // 
            this.adaugareToolStripMenuItem.Name = "adaugareToolStripMenuItem";
            this.adaugareToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.adaugareToolStripMenuItem.Text = "Adaugare";
            this.adaugareToolStripMenuItem.Click += new System.EventHandler(this.adaugareToolStripMenuItem_Click);
            // 
            // modificareToolStripMenuItem
            // 
            this.modificareToolStripMenuItem.Name = "modificareToolStripMenuItem";
            this.modificareToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.modificareToolStripMenuItem.Text = "Modificare";
            // 
            // stergereToolStripMenuItem
            // 
            this.stergereToolStripMenuItem.Name = "stergereToolStripMenuItem";
            this.stergereToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.stergereToolStripMenuItem.Text = "Stergere";
            // 
            // selectareToolStripMenuItem
            // 
            this.selectareToolStripMenuItem.Name = "selectareToolStripMenuItem";
            this.selectareToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.selectareToolStripMenuItem.Text = "Selectare";
            // 
            // adminToolStripMenuItem2
            // 
            this.adminToolStripMenuItem2.Name = "adminToolStripMenuItem2";
            this.adminToolStripMenuItem2.Size = new System.Drawing.Size(194, 22);
            this.adminToolStripMenuItem2.Text = "Admin";
            // 
            // admintopToolStripMenuItem
            // 
            this.admintopToolStripMenuItem.Name = "admintopToolStripMenuItem";
            this.admintopToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.admintopToolStripMenuItem.Text = "admintop";
            // 
            // autoriToolStripMenuItem
            // 
            this.autoriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adaugareToolStripMenuItem2,
            this.modificareToolStripMenuItem2,
            this.stergereToolStripMenuItem2,
            this.selectareToolStripMenuItem2,
            this.generateNavigatorAutoriToolStripMenuItem});
            this.autoriToolStripMenuItem.Name = "autoriToolStripMenuItem";
            this.autoriToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.autoriToolStripMenuItem.Text = "Autori";
            // 
            // adaugareToolStripMenuItem2
            // 
            this.adaugareToolStripMenuItem2.Name = "adaugareToolStripMenuItem2";
            this.adaugareToolStripMenuItem2.Size = new System.Drawing.Size(194, 22);
            this.adaugareToolStripMenuItem2.Text = "Adaugare";
            this.adaugareToolStripMenuItem2.Click += new System.EventHandler(this.adaugareToolStripMenuItem2_Click);
            // 
            // modificareToolStripMenuItem2
            // 
            this.modificareToolStripMenuItem2.Name = "modificareToolStripMenuItem2";
            this.modificareToolStripMenuItem2.Size = new System.Drawing.Size(194, 22);
            this.modificareToolStripMenuItem2.Text = "Modificare";
            // 
            // stergereToolStripMenuItem2
            // 
            this.stergereToolStripMenuItem2.Name = "stergereToolStripMenuItem2";
            this.stergereToolStripMenuItem2.Size = new System.Drawing.Size(194, 22);
            this.stergereToolStripMenuItem2.Text = "Stergere";
            // 
            // selectareToolStripMenuItem2
            // 
            this.selectareToolStripMenuItem2.Name = "selectareToolStripMenuItem2";
            this.selectareToolStripMenuItem2.Size = new System.Drawing.Size(194, 22);
            this.selectareToolStripMenuItem2.Text = "Selectare";
            // 
            // cartiToolStripMenuItem
            // 
            this.cartiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adaugareToolStripMenuItem1,
            this.modificareToolStripMenuItem1,
            this.stergereToolStripMenuItem1,
            this.selectareToolStripMenuItem1,
            this.navigareToolStripMenuItem,
            this.navigareCartiGeneratorToolStripMenuItem,
            this.generatorToolStripMenuItem});
            this.cartiToolStripMenuItem.Name = "cartiToolStripMenuItem";
            this.cartiToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cartiToolStripMenuItem.Text = "Carti";
            // 
            // adaugareToolStripMenuItem1
            // 
            this.adaugareToolStripMenuItem1.Name = "adaugareToolStripMenuItem1";
            this.adaugareToolStripMenuItem1.Size = new System.Drawing.Size(188, 22);
            this.adaugareToolStripMenuItem1.Text = "Adaugare";
            this.adaugareToolStripMenuItem1.Click += new System.EventHandler(this.adaugareToolStripMenuItem1_Click);
            // 
            // modificareToolStripMenuItem1
            // 
            this.modificareToolStripMenuItem1.Name = "modificareToolStripMenuItem1";
            this.modificareToolStripMenuItem1.Size = new System.Drawing.Size(188, 22);
            this.modificareToolStripMenuItem1.Text = "Modificare";
            // 
            // stergereToolStripMenuItem1
            // 
            this.stergereToolStripMenuItem1.Name = "stergereToolStripMenuItem1";
            this.stergereToolStripMenuItem1.Size = new System.Drawing.Size(188, 22);
            this.stergereToolStripMenuItem1.Text = "Stergere";
            // 
            // selectareToolStripMenuItem1
            // 
            this.selectareToolStripMenuItem1.Name = "selectareToolStripMenuItem1";
            this.selectareToolStripMenuItem1.Size = new System.Drawing.Size(188, 22);
            this.selectareToolStripMenuItem1.Text = "Selectare";
            // 
            // navigareToolStripMenuItem
            // 
            this.navigareToolStripMenuItem.Name = "navigareToolStripMenuItem";
            this.navigareToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.navigareToolStripMenuItem.Text = "Navigare";
            this.navigareToolStripMenuItem.Click += new System.EventHandler(this.navigareToolStripMenuItem_Click);
            // 
            // navigareCartiGeneratorToolStripMenuItem
            // 
            this.navigareCartiGeneratorToolStripMenuItem.Name = "navigareCartiGeneratorToolStripMenuItem";
            this.navigareCartiGeneratorToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.navigareCartiGeneratorToolStripMenuItem.Text = "NavigareGenerator";
            this.navigareCartiGeneratorToolStripMenuItem.Click += new System.EventHandler(this.navigareCartiGeneratorToolStripMenuItem_Click);
            // 
            // generatorToolStripMenuItem
            // 
            this.generatorToolStripMenuItem.Name = "generatorToolStripMenuItem";
            this.generatorToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.generatorToolStripMenuItem.Text = "generateNavigatorCarti";
            this.generatorToolStripMenuItem.Click += new System.EventHandler(this.generatorToolStripMenuItem_Click);
            // 
            // domeniiToolStripMenuItem
            // 
            this.domeniiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adaugareToolStripMenuItem8,
            this.modificareToolStripMenuItem8,
            this.stergereToolStripMenuItem8,
            this.selectareToolStripMenuItem8});
            this.domeniiToolStripMenuItem.Name = "domeniiToolStripMenuItem";
            this.domeniiToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.domeniiToolStripMenuItem.Text = "Domenii";
            // 
            // adaugareToolStripMenuItem8
            // 
            this.adaugareToolStripMenuItem8.Name = "adaugareToolStripMenuItem8";
            this.adaugareToolStripMenuItem8.Size = new System.Drawing.Size(123, 22);
            this.adaugareToolStripMenuItem8.Text = "Adaugare";
            // 
            // modificareToolStripMenuItem8
            // 
            this.modificareToolStripMenuItem8.Name = "modificareToolStripMenuItem8";
            this.modificareToolStripMenuItem8.Size = new System.Drawing.Size(123, 22);
            this.modificareToolStripMenuItem8.Text = "Modificare";
            // 
            // stergereToolStripMenuItem8
            // 
            this.stergereToolStripMenuItem8.Name = "stergereToolStripMenuItem8";
            this.stergereToolStripMenuItem8.Size = new System.Drawing.Size(123, 22);
            this.stergereToolStripMenuItem8.Text = "Stergere";
            // 
            // selectareToolStripMenuItem8
            // 
            this.selectareToolStripMenuItem8.Name = "selectareToolStripMenuItem8";
            this.selectareToolStripMenuItem8.Size = new System.Drawing.Size(123, 22);
            this.selectareToolStripMenuItem8.Text = "Selectare";
            // 
            // comentariiToolStripMenuItem
            // 
            this.comentariiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adaugareToolStripMenuItem3,
            this.modificareToolStripMenuItem3,
            this.stergereToolStripMenuItem3,
            this.selectareToolStripMenuItem3,
            this.moderareToolStripMenuItem,
            this.opiniiToolStripMenuItem});
            this.comentariiToolStripMenuItem.Name = "comentariiToolStripMenuItem";
            this.comentariiToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.comentariiToolStripMenuItem.Text = "Comentarii";
            // 
            // adaugareToolStripMenuItem3
            // 
            this.adaugareToolStripMenuItem3.Name = "adaugareToolStripMenuItem3";
            this.adaugareToolStripMenuItem3.Size = new System.Drawing.Size(123, 22);
            this.adaugareToolStripMenuItem3.Text = "Adaugare";
            // 
            // modificareToolStripMenuItem3
            // 
            this.modificareToolStripMenuItem3.Name = "modificareToolStripMenuItem3";
            this.modificareToolStripMenuItem3.Size = new System.Drawing.Size(123, 22);
            this.modificareToolStripMenuItem3.Text = "Modificare";
            // 
            // stergereToolStripMenuItem3
            // 
            this.stergereToolStripMenuItem3.Name = "stergereToolStripMenuItem3";
            this.stergereToolStripMenuItem3.Size = new System.Drawing.Size(123, 22);
            this.stergereToolStripMenuItem3.Text = "Stergere";
            // 
            // selectareToolStripMenuItem3
            // 
            this.selectareToolStripMenuItem3.Name = "selectareToolStripMenuItem3";
            this.selectareToolStripMenuItem3.Size = new System.Drawing.Size(123, 22);
            this.selectareToolStripMenuItem3.Text = "Selectare";
            // 
            // moderareToolStripMenuItem
            // 
            this.moderareToolStripMenuItem.Name = "moderareToolStripMenuItem";
            this.moderareToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.moderareToolStripMenuItem.Text = "Moderare";
            // 
            // opiniiToolStripMenuItem
            // 
            this.opiniiToolStripMenuItem.Name = "opiniiToolStripMenuItem";
            this.opiniiToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.opiniiToolStripMenuItem.Text = "Opinii";
            // 
            // vanzariToolStripMenuItem
            // 
            this.vanzariToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adaugareToolStripMenuItem4,
            this.modificareToolStripMenuItem4,
            this.stergereToolStripMenuItem4,
            this.selectareToolStripMenuItem4});
            this.vanzariToolStripMenuItem.Name = "vanzariToolStripMenuItem";
            this.vanzariToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.vanzariToolStripMenuItem.Text = "Vanzari";
            // 
            // adaugareToolStripMenuItem4
            // 
            this.adaugareToolStripMenuItem4.Name = "adaugareToolStripMenuItem4";
            this.adaugareToolStripMenuItem4.Size = new System.Drawing.Size(123, 22);
            this.adaugareToolStripMenuItem4.Text = "Adaugare";
            // 
            // modificareToolStripMenuItem4
            // 
            this.modificareToolStripMenuItem4.Name = "modificareToolStripMenuItem4";
            this.modificareToolStripMenuItem4.Size = new System.Drawing.Size(123, 22);
            this.modificareToolStripMenuItem4.Text = "Modificare";
            // 
            // stergereToolStripMenuItem4
            // 
            this.stergereToolStripMenuItem4.Name = "stergereToolStripMenuItem4";
            this.stergereToolStripMenuItem4.Size = new System.Drawing.Size(123, 22);
            this.stergereToolStripMenuItem4.Text = "Stergere";
            // 
            // selectareToolStripMenuItem4
            // 
            this.selectareToolStripMenuItem4.Name = "selectareToolStripMenuItem4";
            this.selectareToolStripMenuItem4.Size = new System.Drawing.Size(123, 22);
            this.selectareToolStripMenuItem4.Text = "Selectare";
            // 
            // tranzactiiToolStripMenuItem
            // 
            this.tranzactiiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adaugareToolStripMenuItem5,
            this.modificareToolStripMenuItem5,
            this.stergereToolStripMenuItem5,
            this.selectareToolStripMenuItem5});
            this.tranzactiiToolStripMenuItem.Name = "tranzactiiToolStripMenuItem";
            this.tranzactiiToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.tranzactiiToolStripMenuItem.Text = "Tranzactii";
            // 
            // adaugareToolStripMenuItem5
            // 
            this.adaugareToolStripMenuItem5.Name = "adaugareToolStripMenuItem5";
            this.adaugareToolStripMenuItem5.Size = new System.Drawing.Size(123, 22);
            this.adaugareToolStripMenuItem5.Text = "Adaugare";
            // 
            // modificareToolStripMenuItem5
            // 
            this.modificareToolStripMenuItem5.Name = "modificareToolStripMenuItem5";
            this.modificareToolStripMenuItem5.Size = new System.Drawing.Size(123, 22);
            this.modificareToolStripMenuItem5.Text = "Modificare";
            // 
            // stergereToolStripMenuItem5
            // 
            this.stergereToolStripMenuItem5.Name = "stergereToolStripMenuItem5";
            this.stergereToolStripMenuItem5.Size = new System.Drawing.Size(123, 22);
            this.stergereToolStripMenuItem5.Text = "Stergere";
            // 
            // selectareToolStripMenuItem5
            // 
            this.selectareToolStripMenuItem5.Name = "selectareToolStripMenuItem5";
            this.selectareToolStripMenuItem5.Size = new System.Drawing.Size(123, 22);
            this.selectareToolStripMenuItem5.Text = "Selectare";
            // 
            // clientiToolStripMenuItem
            // 
            this.clientiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adaugareToolStripMenuItem6,
            this.modificareToolStripMenuItem6,
            this.stergereToolStripMenuItem6,
            this.selectareToolStripMenuItem6});
            this.clientiToolStripMenuItem.Name = "clientiToolStripMenuItem";
            this.clientiToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.clientiToolStripMenuItem.Text = "Clienti";
            // 
            // adaugareToolStripMenuItem6
            // 
            this.adaugareToolStripMenuItem6.Name = "adaugareToolStripMenuItem6";
            this.adaugareToolStripMenuItem6.Size = new System.Drawing.Size(123, 22);
            this.adaugareToolStripMenuItem6.Text = "Adaugare";
            // 
            // modificareToolStripMenuItem6
            // 
            this.modificareToolStripMenuItem6.Name = "modificareToolStripMenuItem6";
            this.modificareToolStripMenuItem6.Size = new System.Drawing.Size(123, 22);
            this.modificareToolStripMenuItem6.Text = "Modificare";
            // 
            // stergereToolStripMenuItem6
            // 
            this.stergereToolStripMenuItem6.Name = "stergereToolStripMenuItem6";
            this.stergereToolStripMenuItem6.Size = new System.Drawing.Size(123, 22);
            this.stergereToolStripMenuItem6.Text = "Stergere";
            // 
            // selectareToolStripMenuItem6
            // 
            this.selectareToolStripMenuItem6.Name = "selectareToolStripMenuItem6";
            this.selectareToolStripMenuItem6.Size = new System.Drawing.Size(123, 22);
            this.selectareToolStripMenuItem6.Text = "Selectare";
            // 
            // furnizoriToolStripMenuItem
            // 
            this.furnizoriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adaugareToolStripMenuItem7,
            this.modificareToolStripMenuItem7,
            this.stergereToolStripMenuItem7,
            this.selectareToolStripMenuItem7});
            this.furnizoriToolStripMenuItem.Name = "furnizoriToolStripMenuItem";
            this.furnizoriToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.furnizoriToolStripMenuItem.Text = "Furnizori";
            // 
            // adaugareToolStripMenuItem7
            // 
            this.adaugareToolStripMenuItem7.Name = "adaugareToolStripMenuItem7";
            this.adaugareToolStripMenuItem7.Size = new System.Drawing.Size(123, 22);
            this.adaugareToolStripMenuItem7.Text = "Adaugare";
            // 
            // modificareToolStripMenuItem7
            // 
            this.modificareToolStripMenuItem7.Name = "modificareToolStripMenuItem7";
            this.modificareToolStripMenuItem7.Size = new System.Drawing.Size(123, 22);
            this.modificareToolStripMenuItem7.Text = "Modificare";
            // 
            // stergereToolStripMenuItem7
            // 
            this.stergereToolStripMenuItem7.Name = "stergereToolStripMenuItem7";
            this.stergereToolStripMenuItem7.Size = new System.Drawing.Size(123, 22);
            this.stergereToolStripMenuItem7.Text = "Stergere";
            // 
            // selectareToolStripMenuItem7
            // 
            this.selectareToolStripMenuItem7.Name = "selectareToolStripMenuItem7";
            this.selectareToolStripMenuItem7.Size = new System.Drawing.Size(123, 22);
            this.selectareToolStripMenuItem7.Text = "Selectare";
            // 
            // statisticiToolStripMenuItem
            // 
            this.statisticiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminToolStripMenuItem1,
            this.cartiToolStripMenuItem1,
            this.autoriToolStripMenuItem1,
            this.comentariiToolStripMenuItem1,
            this.vanzariToolStripMenuItem1,
            this.tranzactiiToolStripMenuItem1,
            this.clientiToolStripMenuItem1,
            this.furnizoriToolStripMenuItem1});
            this.statisticiToolStripMenuItem.Name = "statisticiToolStripMenuItem";
            this.statisticiToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.statisticiToolStripMenuItem.Text = "Statistici";
            // 
            // adminToolStripMenuItem1
            // 
            this.adminToolStripMenuItem1.Name = "adminToolStripMenuItem1";
            this.adminToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.adminToolStripMenuItem1.Text = "admin";
            // 
            // cartiToolStripMenuItem1
            // 
            this.cartiToolStripMenuItem1.Name = "cartiToolStripMenuItem1";
            this.cartiToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.cartiToolStripMenuItem1.Text = "carti";
            // 
            // autoriToolStripMenuItem1
            // 
            this.autoriToolStripMenuItem1.Name = "autoriToolStripMenuItem1";
            this.autoriToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.autoriToolStripMenuItem1.Text = "autori";
            // 
            // comentariiToolStripMenuItem1
            // 
            this.comentariiToolStripMenuItem1.Name = "comentariiToolStripMenuItem1";
            this.comentariiToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.comentariiToolStripMenuItem1.Text = "comentarii";
            // 
            // vanzariToolStripMenuItem1
            // 
            this.vanzariToolStripMenuItem1.Name = "vanzariToolStripMenuItem1";
            this.vanzariToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.vanzariToolStripMenuItem1.Text = "vanzari";
            // 
            // tranzactiiToolStripMenuItem1
            // 
            this.tranzactiiToolStripMenuItem1.Name = "tranzactiiToolStripMenuItem1";
            this.tranzactiiToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.tranzactiiToolStripMenuItem1.Text = "tranzactii";
            // 
            // clientiToolStripMenuItem1
            // 
            this.clientiToolStripMenuItem1.Name = "clientiToolStripMenuItem1";
            this.clientiToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.clientiToolStripMenuItem1.Text = "clienti";
            // 
            // furnizoriToolStripMenuItem1
            // 
            this.furnizoriToolStripMenuItem1.Name = "furnizoriToolStripMenuItem1";
            this.furnizoriToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.furnizoriToolStripMenuItem1.Text = "furnizori";
            // 
            // platiToolStripMenuItem
            // 
            this.platiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.plataToolStripMenuItem});
            this.platiToolStripMenuItem.Name = "platiToolStripMenuItem";
            this.platiToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.platiToolStripMenuItem.Text = "Plati";
            // 
            // plataToolStripMenuItem
            // 
            this.plataToolStripMenuItem.Name = "plataToolStripMenuItem";
            this.plataToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.plataToolStripMenuItem.Text = "Plata";
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cautareToolStripMenuItem});
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.searchToolStripMenuItem.Text = "Search";
            // 
            // cautareToolStripMenuItem
            // 
            this.cautareToolStripMenuItem.Name = "cautareToolStripMenuItem";
            this.cautareToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.cautareToolStripMenuItem.Text = "Cautare";
            // 
            // dBToolStripMenuItem
            // 
            this.dBToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectionToolStripMenuItem,
            this.deconectareToolStripMenuItem});
            this.dBToolStripMenuItem.Name = "dBToolStripMenuItem";
            this.dBToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dBToolStripMenuItem.Text = "DB";
            // 
            // connectionToolStripMenuItem
            // 
            this.connectionToolStripMenuItem.Name = "connectionToolStripMenuItem";
            this.connectionToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.connectionToolStripMenuItem.Text = "Connection";
            // 
            // deconectareToolStripMenuItem
            // 
            this.deconectareToolStripMenuItem.Name = "deconectareToolStripMenuItem";
            this.deconectareToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.deconectareToolStripMenuItem.Text = "Deconectare";
            // 
            // exportToolStripMenuItem
            // 
            this.exportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportToToolStripMenuItem});
            this.exportToolStripMenuItem.Name = "exportToolStripMenuItem";
            this.exportToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exportToolStripMenuItem.Text = "Export";
            // 
            // exportToToolStripMenuItem
            // 
            this.exportToToolStripMenuItem.Name = "exportToToolStripMenuItem";
            this.exportToToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.exportToToolStripMenuItem.Text = "ExportTo";
            // 
            // importToolStripMenuItem
            // 
            this.importToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importFromToolStripMenuItem});
            this.importToolStripMenuItem.Name = "importToolStripMenuItem";
            this.importToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.importToolStripMenuItem.Text = "Import";
            // 
            // importFromToolStripMenuItem
            // 
            this.importFromToolStripMenuItem.Name = "importFromToolStripMenuItem";
            this.importFromToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.importFromToolStripMenuItem.Text = "ImportFrom";
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(96, 22);
            this.printToolStripMenuItem.Text = "print";
            // 
            // publicareToolStripMenuItem
            // 
            this.publicareToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.facebookToolStripMenuItem,
            this.socialeNetworkToolStripMenuItem,
            this.toFlierToolStripMenuItem,
            this.toPDFToolStripMenuItem,
            this.toWebToolStripMenuItem});
            this.publicareToolStripMenuItem.Name = "publicareToolStripMenuItem";
            this.publicareToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.publicareToolStripMenuItem.Text = "Publicare";
            // 
            // facebookToolStripMenuItem
            // 
            this.facebookToolStripMenuItem.Name = "facebookToolStripMenuItem";
            this.facebookToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.facebookToolStripMenuItem.Text = "facebook";
            // 
            // socialeNetworkToolStripMenuItem
            // 
            this.socialeNetworkToolStripMenuItem.Name = "socialeNetworkToolStripMenuItem";
            this.socialeNetworkToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.socialeNetworkToolStripMenuItem.Text = "socialeNetwork";
            // 
            // toFlierToolStripMenuItem
            // 
            this.toFlierToolStripMenuItem.Name = "toFlierToolStripMenuItem";
            this.toFlierToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.toFlierToolStripMenuItem.Text = "toFlier";
            // 
            // toPDFToolStripMenuItem
            // 
            this.toPDFToolStripMenuItem.Name = "toPDFToolStripMenuItem";
            this.toPDFToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.toPDFToolStripMenuItem.Text = "toPDF";
            // 
            // toWebToolStripMenuItem
            // 
            this.toWebToolStripMenuItem.Name = "toWebToolStripMenuItem";
            this.toWebToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.toWebToolStripMenuItem.Text = "toWeb";
            // 
            // magazinToolStripMenuItem
            // 
            this.magazinToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.companieToolStripMenuItem,
            this.formulareToolStripMenuItem,
            this.frontEndToolStripMenuItem,
            this.backEndToolStripMenuItem,
            this.curierToolStripMenuItem,
            this.dashBoardToolStripMenuItem,
            this.fiscalitateToolStripMenuItem,
            this.contabilitateToolStripMenuItem,
            this.reteleSocialeToolStripMenuItem,
            this.legalToolStripMenuItem,
            this.securitateToolStripMenuItem});
            this.magazinToolStripMenuItem.Name = "magazinToolStripMenuItem";
            this.magazinToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.magazinToolStripMenuItem.Text = "Magazin";
            // 
            // companieToolStripMenuItem
            // 
            this.companieToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.companyToolStripMenuItem});
            this.companieToolStripMenuItem.Name = "companieToolStripMenuItem";
            this.companieToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.companieToolStripMenuItem.Text = "Companie";
            // 
            // companyToolStripMenuItem
            // 
            this.companyToolStripMenuItem.Name = "companyToolStripMenuItem";
            this.companyToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.companyToolStripMenuItem.Text = "Company";
            // 
            // formulareToolStripMenuItem
            // 
            this.formulareToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.indexToolStripMenuItem,
            this.lastProductsToolStripMenuItem,
            this.mainFormToolStripMenuItem,
            this.meniuLateralStangaToolStripMenuItem,
            this.productListToolStripMenuItem,
            this.topFormToolStripMenuItem});
            this.formulareToolStripMenuItem.Name = "formulareToolStripMenuItem";
            this.formulareToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.formulareToolStripMenuItem.Text = "Formulare";
            // 
            // indexToolStripMenuItem
            // 
            this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
            this.indexToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.indexToolStripMenuItem.Text = "index";
            // 
            // lastProductsToolStripMenuItem
            // 
            this.lastProductsToolStripMenuItem.Name = "lastProductsToolStripMenuItem";
            this.lastProductsToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.lastProductsToolStripMenuItem.Text = "lastProducts";
            // 
            // mainFormToolStripMenuItem
            // 
            this.mainFormToolStripMenuItem.Name = "mainFormToolStripMenuItem";
            this.mainFormToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.mainFormToolStripMenuItem.Text = "mainForm";
            // 
            // meniuLateralStangaToolStripMenuItem
            // 
            this.meniuLateralStangaToolStripMenuItem.Name = "meniuLateralStangaToolStripMenuItem";
            this.meniuLateralStangaToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.meniuLateralStangaToolStripMenuItem.Text = "meniuLateralStanga";
            // 
            // productListToolStripMenuItem
            // 
            this.productListToolStripMenuItem.Name = "productListToolStripMenuItem";
            this.productListToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.productListToolStripMenuItem.Text = "productList";
            // 
            // topFormToolStripMenuItem
            // 
            this.topFormToolStripMenuItem.Name = "topFormToolStripMenuItem";
            this.topFormToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.topFormToolStripMenuItem.Text = "topForm";
            // 
            // frontEndToolStripMenuItem
            // 
            this.frontEndToolStripMenuItem.Name = "frontEndToolStripMenuItem";
            this.frontEndToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.frontEndToolStripMenuItem.Text = "FrontEnd";
            // 
            // backEndToolStripMenuItem
            // 
            this.backEndToolStripMenuItem.Name = "backEndToolStripMenuItem";
            this.backEndToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.backEndToolStripMenuItem.Text = "BackEnd";
            // 
            // curierToolStripMenuItem
            // 
            this.curierToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.curieratToolStripMenuItem});
            this.curierToolStripMenuItem.Name = "curierToolStripMenuItem";
            this.curierToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.curierToolStripMenuItem.Text = "Curier";
            // 
            // curieratToolStripMenuItem
            // 
            this.curieratToolStripMenuItem.Name = "curieratToolStripMenuItem";
            this.curieratToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.curieratToolStripMenuItem.Text = "Curierat";
            // 
            // dashBoardToolStripMenuItem
            // 
            this.dashBoardToolStripMenuItem.Name = "dashBoardToolStripMenuItem";
            this.dashBoardToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.dashBoardToolStripMenuItem.Text = "DashBoard";
            // 
            // fiscalitateToolStripMenuItem
            // 
            this.fiscalitateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bancaToolStripMenuItem,
            this.caseriaToolStripMenuItem,
            this.impozitToolStripMenuItem,
            this.taxeToolStripMenuItem,
            this.tVAToolStripMenuItem});
            this.fiscalitateToolStripMenuItem.Name = "fiscalitateToolStripMenuItem";
            this.fiscalitateToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.fiscalitateToolStripMenuItem.Text = "Fiscalitate";
            // 
            // bancaToolStripMenuItem
            // 
            this.bancaToolStripMenuItem.Name = "bancaToolStripMenuItem";
            this.bancaToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.bancaToolStripMenuItem.Text = "Banca";
            // 
            // caseriaToolStripMenuItem
            // 
            this.caseriaToolStripMenuItem.Name = "caseriaToolStripMenuItem";
            this.caseriaToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.caseriaToolStripMenuItem.Text = "Caseria";
            // 
            // impozitToolStripMenuItem
            // 
            this.impozitToolStripMenuItem.Name = "impozitToolStripMenuItem";
            this.impozitToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.impozitToolStripMenuItem.Text = "Impozite";
            // 
            // taxeToolStripMenuItem
            // 
            this.taxeToolStripMenuItem.Name = "taxeToolStripMenuItem";
            this.taxeToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.taxeToolStripMenuItem.Text = "Taxe";
            // 
            // tVAToolStripMenuItem
            // 
            this.tVAToolStripMenuItem.Name = "tVAToolStripMenuItem";
            this.tVAToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.tVAToolStripMenuItem.Text = "TVA";
            // 
            // contabilitateToolStripMenuItem
            // 
            this.contabilitateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bilantToolStripMenuItem,
            this.costuriToolStripMenuItem,
            this.personalToolStripMenuItem,
            this.pierderiToolStripMenuItem,
            this.profitToolStripMenuItem,
            this.stocuriToolStripMenuItem,
            this.venituriToolStripMenuItem});
            this.contabilitateToolStripMenuItem.Name = "contabilitateToolStripMenuItem";
            this.contabilitateToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.contabilitateToolStripMenuItem.Text = "Contabilitate";
            // 
            // bilantToolStripMenuItem
            // 
            this.bilantToolStripMenuItem.Name = "bilantToolStripMenuItem";
            this.bilantToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.bilantToolStripMenuItem.Text = "Bilant";
            // 
            // costuriToolStripMenuItem
            // 
            this.costuriToolStripMenuItem.Name = "costuriToolStripMenuItem";
            this.costuriToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.costuriToolStripMenuItem.Text = "Costuri";
            // 
            // personalToolStripMenuItem
            // 
            this.personalToolStripMenuItem.Name = "personalToolStripMenuItem";
            this.personalToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.personalToolStripMenuItem.Text = "Personal";
            // 
            // pierderiToolStripMenuItem
            // 
            this.pierderiToolStripMenuItem.Name = "pierderiToolStripMenuItem";
            this.pierderiToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.pierderiToolStripMenuItem.Text = "Pierderi";
            // 
            // profitToolStripMenuItem
            // 
            this.profitToolStripMenuItem.Name = "profitToolStripMenuItem";
            this.profitToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.profitToolStripMenuItem.Text = "Profit";
            // 
            // stocuriToolStripMenuItem
            // 
            this.stocuriToolStripMenuItem.Name = "stocuriToolStripMenuItem";
            this.stocuriToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.stocuriToolStripMenuItem.Text = "Stocuri";
            // 
            // venituriToolStripMenuItem
            // 
            this.venituriToolStripMenuItem.Name = "venituriToolStripMenuItem";
            this.venituriToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.venituriToolStripMenuItem.Text = "Venituri";
            // 
            // reteleSocialeToolStripMenuItem
            // 
            this.reteleSocialeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.emailToolStripMenuItem});
            this.reteleSocialeToolStripMenuItem.Name = "reteleSocialeToolStripMenuItem";
            this.reteleSocialeToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.reteleSocialeToolStripMenuItem.Text = "ReteleSociale";
            // 
            // emailToolStripMenuItem
            // 
            this.emailToolStripMenuItem.Name = "emailToolStripMenuItem";
            this.emailToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.emailToolStripMenuItem.Text = "Email";
            // 
            // legalToolStripMenuItem
            // 
            this.legalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyrightToolStripMenuItem});
            this.legalToolStripMenuItem.Name = "legalToolStripMenuItem";
            this.legalToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.legalToolStripMenuItem.Text = "Legal";
            // 
            // copyrightToolStripMenuItem
            // 
            this.copyrightToolStripMenuItem.Name = "copyrightToolStripMenuItem";
            this.copyrightToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.copyrightToolStripMenuItem.Text = "copyright";
            // 
            // securitateToolStripMenuItem
            // 
            this.securitateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.securityToolStripMenuItem,
            this.autentificareToolStripMenuItem});
            this.securitateToolStripMenuItem.Name = "securitateToolStripMenuItem";
            this.securitateToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.securitateToolStripMenuItem.Text = "Securitate";
            // 
            // securityToolStripMenuItem
            // 
            this.securityToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sesiuneToolStripMenuItem,
            this.autorizareToolStripMenuItem});
            this.securityToolStripMenuItem.Name = "securityToolStripMenuItem";
            this.securityToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.securityToolStripMenuItem.Text = "Security";
            // 
            // sesiuneToolStripMenuItem
            // 
            this.sesiuneToolStripMenuItem.Name = "sesiuneToolStripMenuItem";
            this.sesiuneToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.sesiuneToolStripMenuItem.Text = "Sesiune";
            // 
            // autorizareToolStripMenuItem
            // 
            this.autorizareToolStripMenuItem.Name = "autorizareToolStripMenuItem";
            this.autorizareToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.autorizareToolStripMenuItem.Text = "Autorizare";
            // 
            // autentificareToolStripMenuItem
            // 
            this.autentificareToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginToolStripMenuItem,
            this.signupToolStripMenuItem,
            this.signinToolStripMenuItem});
            this.autentificareToolStripMenuItem.Name = "autentificareToolStripMenuItem";
            this.autentificareToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.autentificareToolStripMenuItem.Text = "Autentificare";
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.loginToolStripMenuItem.Text = "login";
            // 
            // signupToolStripMenuItem
            // 
            this.signupToolStripMenuItem.Name = "signupToolStripMenuItem";
            this.signupToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.signupToolStripMenuItem.Text = "signup";
            // 
            // signinToolStripMenuItem
            // 
            this.signinToolStripMenuItem.Name = "signinToolStripMenuItem";
            this.signinToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.signinToolStripMenuItem.Text = "signin";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ajutorToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.splashScreenToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // ajutorToolStripMenuItem
            // 
            this.ajutorToolStripMenuItem.Name = "ajutorToolStripMenuItem";
            this.ajutorToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.ajutorToolStripMenuItem.Text = "Ajutor";
            this.ajutorToolStripMenuItem.Click += new System.EventHandler(this.ajutorToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // splashScreenToolStripMenuItem
            // 
            this.splashScreenToolStripMenuItem.Name = "splashScreenToolStripMenuItem";
            this.splashScreenToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.splashScreenToolStripMenuItem.Text = "SplashScreen";
            this.splashScreenToolStripMenuItem.Click += new System.EventHandler(this.splashScreenToolStripMenuItem_Click);
            // 
            // generateNavigatorAdminToolStripMenuItem
            // 
            this.generateNavigatorAdminToolStripMenuItem.Name = "generateNavigatorAdminToolStripMenuItem";
            this.generateNavigatorAdminToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.generateNavigatorAdminToolStripMenuItem.Text = "generateNavigatorAdmin";
            this.generateNavigatorAdminToolStripMenuItem.Click += new System.EventHandler(this.generateNavigatorAdminToolStripMenuItem_Click);
            // 
            // generateNavigatorAutoriToolStripMenuItem
            // 
            this.generateNavigatorAutoriToolStripMenuItem.Name = "generateNavigatorAutoriToolStripMenuItem";
            this.generateNavigatorAutoriToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.generateNavigatorAutoriToolStripMenuItem.Text = "generateNavigatorAutori";
            this.generateNavigatorAutoriToolStripMenuItem.Click += new System.EventHandler(this.generateNavigatorAutoriToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(709, 438);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Librarie";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adaugareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modificareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stergereToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem cartiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adaugareToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem modificareToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem stergereToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem selectareToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem autoriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adaugareToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem modificareToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem stergereToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem selectareToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem comentariiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adaugareToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem modificareToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem stergereToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem selectareToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem vanzariToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adaugareToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem modificareToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem stergereToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem selectareToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem tranzactiiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adaugareToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem modificareToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem stergereToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem selectareToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem clientiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adaugareToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem modificareToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem stergereToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem selectareToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem furnizoriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adaugareToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem modificareToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem stergereToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem selectareToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem statisticiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cartiToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem autoriToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem comentariiToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem vanzariToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tranzactiiToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem clientiToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem furnizoriToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem moderareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem opiniiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem platiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem plataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cautareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem connectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deconectareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportToToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importFromToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem publicareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem facebookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem socialeNetworkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toFlierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toPDFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toWebToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem magazinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formulareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lastProductsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mainFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem meniuLateralStangaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem topFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frontEndToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backEndToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem curierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem curieratToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem companieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dashBoardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem admintopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajutorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem companyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fiscalitateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bancaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem caseriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem impozitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem taxeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tVAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contabilitateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bilantToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem costuriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem personalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pierderiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem profitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stocuriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem venituriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reteleSocialeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem emailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem legalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyrightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem securitateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem securityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sesiuneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem autorizareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem autentificareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem signupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem signinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem splashScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem navigareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem domeniiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adaugareToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem modificareToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem stergereToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem selectareToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem navigareCartiGeneratorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generateNavigatorAdminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generateNavigatorAutoriToolStripMenuItem;
    }
}

